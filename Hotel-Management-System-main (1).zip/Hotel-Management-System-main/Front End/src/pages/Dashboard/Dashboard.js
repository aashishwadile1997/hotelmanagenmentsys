import React, { useContext, useEffect, useState } from 'react'
import styled from 'styled-components'
import { GlobalContext } from '../../utils/Context'
import RoomsList from './RoomsList'
import HotelIMG from "../../assets/hotel.png"
import EditIcon from '@mui/icons-material/Edit';
import AddIcon from '@mui/icons-material/Add';
import "./dashboard.css"
import { getDate } from '../../utils/utilFunctions'
import RoomModal from '../../components/Modals/RoomModal'
import { PageContainer } from '../../components/GlobalStyles/PageStyles'
import HotelModal from '../../components/Modals/HotelModal'
import PageLoader from '../../components/Loaders/PageLoader'
import Stat from './Stats/Stat'
import PageError from '../../components/Error/PageError'
import ViewBookings from '../../components/Modals/ViewBookings'
import ViewFeedback from '../../components/Modals/ViewFeedback'
import { getHotel } from '../../services/HotelService'
import { getRooms } from '../../services/RoomService.'
import ClipLoader from "react-spinners/ClipLoader";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
const QuickView = styled.div`
    display: grid;
    grid-template-columns: 1fr 2fr;
    height: 360px
`
const Info = styled.div`
    width: 100%;
    height: 100%;
    border-radius: 20px;
    background: grey;
    margin-right: 10px;
    max-width: -webkit-fill-available;
    position: relative;
    overflow: hidden;
    background-position: center;
    background-size: cover;
    background-repeat: no-repeat;
    color: #fff;
    .card-details{
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        background: #00000066;
        padding: 16px;
    }
`
const Controls = styled.div`
    width: 100%;
    position: absolute;
    bottom: 0;
    right: 0;
    left: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    color: #fff;
    text-align: center;
    .card-option{
        background: #0000009c;
        width: 100%;
        padding: 10px;
        cursor: pointer;
        :hover{
            background: #383838
        }
    }
`

const StatContainer = styled.div`
    width: 100%;
    padding: 20px;
    border-radius: 20px;
    border: 1px solid orange;
    margin-left: 10px;
    max-width: -webkit-fill-available;
`

const CardText = styled.div`
    width: 80%;
    text-overflow: ellipsis;
    overflow: hidden;
    margin-top: 10px;
    white-space: nowrap;
    span{
        font-weight: bold
    }
`

const Dashboard = () => {

    const user = JSON.parse(localStorage.getItem('user'))

    const [loading, setLoading] = useState(false)
    const [hotel, setHotelDetails] = useState({})
    const [rooms, setRooms] = useState([])
    const [roomModal, setRoomModal] = useState({
        state: false,
        title: '',
        param: null,
        action: ''
    })
    const [hotelModal, setHotelModal] = useState({
        state: false,
        title: '',
        param: null,
        action: ''
    })
    const [bookingsModal, setBookingsModal] = useState({
        state: false,
        title: '',
        param: null,
        action: ''
    })
    const [feedbackModal, setFeedbackModal] = useState({
        state: false,
        title: '',
        param: null,
        action: ''
    })

    const getTotalRooms = (hotelId = hotel.HotelId, userId = user.id) => {
        getRooms(hotelId, userId).then(res => {
            setRooms(res.data)
        })
    }

    const getHotelDetails = () => {
        setLoading(true)
        getHotel(user.id).then(res => {
            if (res.data.length) {
                setHotelDetails(res.data[0])
                setHotelModal({...hotel, params : res.data[0]})
                getTotalRooms(res.data[0].HotelId, user.id)
            }
            setLoading(false)

        }).catch(err => {
            console.log(err)
        })
    }

    useEffect(() => {
        getHotelDetails()
    }, [])

    const controls = [
        {
            label: 'Create Room', icon: <AddIcon />, action: () => {
                if (!hotel?.HotelId) {
                    toast.error("Please update the hotel details first", {
                        autoClose: 5000,
                        pauseOnHover: true
                    })
                    return
                }
                setRoomModal({ state: true, title: 'Add New Room', params: null, action: 'add' })
            }
        },
        {
            label: 'Edit Hotel', icon: <EditIcon />, action: () =>
                setHotelModal({ state: true, title: 'Update Hotel Details', params: null })
        }
    ]

    return (
        <PageContainer>

            {roomModal.state && (<RoomModal
                action={roomModal.action} title={roomModal.title} hotel={hotel} room={roomModal.param}
                callBack={getTotalRooms}
                setRoomModal={setRoomModal} />)}

            {hotelModal.state && (<HotelModal
                action={hotelModal.action} title={hotelModal.title} hotel={hotel} callBack={getHotelDetails}
                setHotelModal={setHotelModal} />)}

            {bookingsModal.state && (<ViewBookings
                title={bookingsModal.title}
                setBookingsModal={setBookingsModal}
                hotel={hotel}
                bookings={bookingsModal.param} />)}

            {feedbackModal.state && (<ViewFeedback
                title={feedbackModal.title}
                setfeedbackModal={setFeedbackModal}
                hotel={hotel}
            />)}

            <QuickView>
                {!loading ? <Info style={{ backgroundImage: `url(${hotel?.Image ? hotel?.Image : HotelIMG})` }}>
                    <div className="card-details">
                        <h1>{hotel.Name}</h1>
                        <p>{hotel.Location}</p>
                        <p className="description">
                            {hotel.Description}
                        </p>
                        <CardText>Total Rooms : <span>{hotel.TotalRooms}</span></CardText>
                        <CardText>Manager: <span>{user.name}</span></CardText>
                    </div>
                    <Controls>
                        {controls.map((c, i) => (
                            <div key={i} className="card-option" onClick={c.action}>
                                {c.icon}
                                <p>{c.label}</p>
                            </div>
                        ))}
                    </Controls>
                </Info> :  <ClipLoader loading={loading} size={50} />}
                <StatContainer>
                    <Stat hotel={hotel} setBookingsModal={setBookingsModal} setFeedbackModal={setFeedbackModal} rooms={rooms} />
                </StatContainer>
            </QuickView>
            <RoomsList callBack={getHotelDetails} rooms={rooms} setRoomModal={setRoomModal} />

        </PageContainer>
    )
}

export default Dashboard
