package com.api.HotelBookingApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class HotelBookingApp {

	public static void main(String[] args) {
		SpringApplication.run(HotelBookingApp.class, args);
	}

}